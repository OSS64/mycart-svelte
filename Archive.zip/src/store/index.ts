import { _CartStore } from './cart.store'

export const CartStore = new _CartStore()
