<div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="false">
      <div class="carousel-indicators">
        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="3" aria-label="Slide 4"></button>
        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="4" aria-label="Slide 5"></button>
      </div>
      <div class="carousel-inner">
        <div class="carousel-item active">
        <div class="img-height">
          <img src="./content/images/hdd.jpg" class="d-block w-100" alt="hdd" >
        </div>
          <div class="carousel-caption d-none d-md-block">
            <h5>Hard Disk Drives</h5>
            <p>Super fast HDDs, availabe from 500gb to 10tb</p>
          </div>
        </div>
        <div class="carousel-item">
          <div class="img-height">
          <img src="./content/images/processor.jpg" class="d-block w-100" alt="processor">
          </div>
          <div class="carousel-caption d-none d-md-block">
            <h5>Processors</h5>
            <p>The very best in computing with the latest processors from Intel,AMD and more.</p>
          </div>
        </div>
        <div class="carousel-item">
          <div class="img-height">
          <img src="./content/images/gpu.jpg" class="d-block w-100" alt="gpu" >
          </div>
          <div class="carousel-caption d-none d-md-block">
            <h5>GPUs</h5>
            <p>The newest 30 range GPU for you gaming experience.</p>
          </div>
        </div>
        <div class="carousel-item">
          <div class="img-height">
          <img src="./content/images/peripherals.jpg" class="d-block w-100" alt="peripherals" >
          </div>
          <div class="carousel-caption d-none d-md-block">
            <h5>Peripherals</h5>
            <p>All the necessary peripherals for you PC/Laptop from mouse and keyboard to earphones and speakers.</p>
          </div>
        </div>
        <div class="carousel-item">
          <div class="img-height">
          <img src="./content/images/laptop.jpg" class="d-block w-100" alt="laptop" >
          </div>
          <div class="carousel-caption d-none d-md-block">
            <h5>Laptops</h5>
            <p>Latest models of laptops for personal use, work or office use.</p>
          </div>
        </div>
      </div>
      <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
      </button>
    </div>

    <style>
      .img-height {
        /*height: 300px;*/
        filter: brightness(50%);
      }
    </style>