export const priceStore = [
  {
    text: "All",
    PriceLow: "",
    PriceUp: "",
  },
  {
    text: "less than 30k",
    PriceLow: 1,
    PriceUp: 30000,
  },
  {
    text: "30k to 40k",
    PriceLow: 30000,
    PriceUp: 40000,
  },
  {
    text: "40k to 50k",
    PriceLow: 40000,
    PriceUp: 50000,
  },
  {
    text: "50k to 60k",
    PriceLow: 50000,
    PriceUp: 60000,
  },
  {
    text: "60k and above",
    PriceLow: 60000,
    PriceUp: 999999999999999,
  },
];
