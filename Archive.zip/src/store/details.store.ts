import { writable} from "svelte/store";

export const productQuantity = writable(1);
