declare module "svelte-confirm";
