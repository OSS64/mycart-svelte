declare module "svelte-confirm";
